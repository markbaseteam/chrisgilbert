Speaking to Ciaron about our wedding

