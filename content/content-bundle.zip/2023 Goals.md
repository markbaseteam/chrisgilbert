---
dg-publish: true
---
- [ ] ~~Run further and more often, try to get to half marathon distances
- [ ] Relax and have fun whenever possible, be less serious
- [ ] Get the kids out doing more things
- [ ] Continue to be careful and organised with money
- [ ] Get the house in a better organised state, get rid of stuff, improve storage
- [ ] Consider career PD around the summer
- [ ] Find out about visiting Jamie again
- [x] Plan a summer holiday with the family ✅ 2023-08-07


- PD:
	- Typescript - can write stuff in 
	- Carve out time to spend on DevOps learning
	