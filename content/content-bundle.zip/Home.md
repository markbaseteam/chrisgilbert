
---
dg-publish: true
dg-home: true
---

This is my digital garden - a collection of notes and thoughts. It is not highly edited, or refined.

I am publishing using Obsidian, along with the Digital Garden plugin, which I am experimenting adding to my daily workflow.

